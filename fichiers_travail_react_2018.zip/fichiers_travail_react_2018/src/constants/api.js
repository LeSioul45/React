const API_KEY = '8aecbcc4'

export default API_KEY
