export { default } from './Movie'
