export { default } from './Details'
